# Interview Me: Practical Examples by Mode

This reference contains practical examples for each interview mode. Use the examples to guide question selection and transitions, not as rigid scripts.

## Shared interaction pattern

Each mode follows the same conversational pattern:

```text
HYPOTHESIS: <current interpretation of the user's intent>
CONFIDENCE: <0-100%> — <what remains unclear, when below approximately 70%>
Q: <one focused question>
GUESS: <the likely answer and why it matters>
```

At the end of a mode, produce its modular summary, declare confidence, recommend at most one next mode, and ask for confirmation before transitioning.

---

## 1. Problem Framing

### Example 1: Delayed internal approvals

**User:** Our approval process is too slow. Help me fix it.

**Agent:**

```text
HYPOTHESIS: The main issue is not the approval policy itself, but the time requests spend waiting for an identifiable decision owner.
CONFIDENCE: ~35% — missing: where delays occur, who is affected, and what evidence is available.
Q: At which point does a request usually stop moving: initial submission, review, or final decision?
GUESS: Review, because requests probably reach the right function but wait for someone to take ownership.
```

**User:** They usually stop during legal review.

**Agent:**

```text
Updated read: the bottleneck is concentrated in legal review rather than across the whole process.
CONFIDENCE: ~55% — still missing: whether the delay comes from workload, incomplete inputs, or unclear ownership.
Q: When Legal receives a request, is the information usually complete enough to review immediately?
GUESS: No. I suspect Legal spends time requesting missing context, which makes the apparent review delay partly an intake-quality problem.
```

**User:** Correct. Most requests are missing attachments or commercial context.

**Agent:**

```text
Updated read: the visible symptom is slow legal review, while the likely operational cause is incomplete intake.
CONFIDENCE: ~80% — still unclear: the business impact and whether this pattern is supported by data.
Q: What consequence matters most when this happens: missed customer deadlines, internal effort, or commercial risk?
GUESS: Missed customer deadlines, because approval delays usually become urgent when they block a commitment to a customer.
```

**Example modular summary:**

```markdown
## Problem Framing Summary

- **Current situation:** Legal review frequently begins with incomplete requests.
- **Problem:** Missing attachments and commercial context create repeated clarification cycles.
- **Impact:** Customer-related commitments are delayed and internal effort increases.
- **Affected stakeholders:** Requesting teams, Legal, commercial owners, and customers awaiting a decision.
- **Evidence:** Repeated requests for missing information; quantitative baseline still to be collected.
- **Likely causes:** Incomplete intake requirements and unclear submission standards.
- **Unverified assumptions:** Legal capacity may contribute, but has not yet been established.
- **Desired situation:** Complete requests reach Legal with sufficient context for immediate review.
- **In scope:** Intake quality and handoff into Legal review.
- **Out of scope:** Redesigning the complete company approval policy.
```

**Transition proposal:**

```text
CONFIDENCE: ~95%
The problem is sufficiently defined. Brainstorming is the most useful next mode because no intervention has been selected yet. Do you agree to move to Brainstorming?
```

### Example 2: Low participation in project meetings

**User:** People do not participate in our project meetings.

**Agent:**

```text
HYPOTHESIS: The meetings are being used mostly for status reporting, so participants do not see a decision or contribution that requires their involvement.
CONFIDENCE: ~40% — missing: meeting purpose, participant behavior, and impact.
Q: What do you expect participants to do during the meeting that they are not doing now?
GUESS: Raise risks and make decisions, rather than merely listen to status updates.
```

**Useful follow-up directions:**

- Ask for an observable example instead of accepting “low engagement.”
- Separate attendance, speaking time, decision quality, and follow-through.
- Check whether the issue is meeting design, psychological safety, unclear roles, or lack of preparation.
- Define the desired behavior without prescribing a solution such as “use a new meeting format.”

---

## 2. Brainstorming

### Example 1: Improve workshop attendance

**User:** Give me ideas to increase attendance at our internal AI workshops.

**Agent:**

```text
HYPOTHESIS: Attendance is limited less by awareness and more by employees not seeing immediate relevance to their role.
CONFIDENCE: ~45% — missing: target audience, current attendance pattern, constraints, and how ideas will be evaluated.
Q: Which employee group do you most want to attend the next workshops?
GUESS: Non-technical project and operations roles, because they may benefit from practical AI use cases but not identify with technically framed sessions.
```

**User:** Project managers and business analysts.

**Agent:**

```text
Updated read: ideas should make the workshops feel directly applicable to project and analysis work.
CONFIDENCE: ~65% — still missing: whether the main barrier is scheduling, perceived value, or manager support.
Q: What feedback have non-attendees given, if any?
GUESS: They say they are interested but cannot justify the time because the expected outcome is too vague.
```

**Example idea categories after clarification:**

1. **Role relevance:** sessions titled around concrete jobs, such as “Turn meeting notes into action registers” or “Draft a project risk review with Copilot.”
2. **Low commitment:** 20-minute demonstrations, office hours, and recorded five-minute recaps.
3. **Manager activation:** team-level nominations and workshop time protected by managers.
4. **Social proof:** internal case studies from project managers and business analysts.
5. **Participation design:** participants bring one real task and leave with an improved artifact.

**Example modular summary:**

```markdown
## Brainstorming Summary

- **Challenge:** Increase attendance among project managers and business analysts.
- **Target audience:** Employees in project and analysis roles with limited time for general training.
- **Constraints:** Short preparation time, existing collaboration tools, and no additional event budget.
- **Evaluation criteria:** Role relevance, ease of implementation, expected attendance impact, and repeatability.
- **Ideas generated:** Role-based sessions, short demonstrations, manager-sponsored attendance, internal case studies, and bring-your-own-task formats.
- **Idea categories:** Relevance, accessibility, sponsorship, social proof, and hands-on participation.
- **Shortlisted ideas:** Role-based workshop titles; bring-your-own-task sessions; 20-minute demonstrations.
- **Ideas excluded:** Broad awareness campaigns without role-specific value.
- **Open questions:** Current attendance baseline and manager willingness to reserve learning time.
```

**Transition proposal:**

```text
CONFIDENCE: ~95%
The idea space is sufficiently explored and three options meet the agreed criteria. I recommend Project Definition for the bring-your-own-task workshop. Do you agree?
```

### Example 2: Generate alternatives without premature selection

**User:** We need a better way to share project updates.

**Agent:**

```text
HYPOTHESIS: You want alternatives to recurring status meetings, but the real need is consistent visibility for stakeholders.
CONFIDENCE: ~50% — unclear: audience, update frequency, and whether the priority is speed, completeness, or discussion.
Q: Who needs the updates, and what decision should the information help them make?
GUESS: Your manager and adjacent teams need to identify risks and dependencies without attending another meeting.
```

**Useful idea families:**

- asynchronous summaries;
- exception-based reporting;
- milestone dashboards;
- decision and risk logs;
- short review sessions triggered only by material changes.

Do not select an idea until the evaluation criteria are understood.

---

## 3. Project Definition

### Example 1: Launch an internal knowledge hub

**User:** We want to create a knowledge hub for our department.

**Agent:**

```text
HYPOTHESIS: The project should reduce time spent searching for approved procedures and reusable materials, rather than simply create another document repository.
CONFIDENCE: ~40% — missing: primary users, expected behavior change, ownership, scope, and success criteria.
Q: What should employees be able to find or do faster because this hub exists?
GUESS: Locate the current approved procedure and a reusable template without asking colleagues in chat.
```

**User:** Exactly. Procedures, templates, and examples.

**Agent:**

```text
Updated read: the project outcome is trusted self-service access to current operational content.
CONFIDENCE: ~65% — still missing: content ownership, first-release scope, and how success will be measured.
Q: Who will be accountable for keeping each item current after launch?
GUESS: Content owners in each functional area, with one central coordinator enforcing review dates and structure.
```

**Example modular summary:**

```markdown
## Project Definition Summary

- **Project purpose:** Reduce time spent searching for current procedures, templates, and approved examples.
- **Objective:** Give department employees a trusted self-service location for frequently used operational knowledge.
- **Primary deliverable:** A first-release knowledge hub with agreed information architecture, priority content, ownership, and review dates.
- **Expected benefit:** Faster retrieval, fewer repetitive questions, and reduced use of outdated materials.
- **Stakeholders:** Department employees, functional content owners, project lead, and department sponsor.
- **Owner:** Knowledge hub project lead.
- **Decision maker:** Department sponsor.
- **In scope:** Priority procedures, templates, examples, metadata, ownership, and review process.
- **Out of scope:** Migrating every historic document and replacing specialist systems.
- **Timeline:** Pilot in one functional area before department-wide rollout.
- **Primary constraint:** Ongoing content ownership, not the technology platform.
- **Key dependencies:** Named content owners, access permissions, and agreement on the initial content set.
- **Main risks:** Low trust caused by outdated content; uncontrolled duplication; unclear ownership.
- **Success criteria:** Users can find priority materials without escalation; content has an owner and review date; outdated versions are removed or clearly archived.
```

**Transition proposal:**

```text
CONFIDENCE: ~95%
The project is sufficiently defined for planning. I recommend moving to Task Definition to identify the pilot activities, owners, dependencies, and completion criteria. Do you agree?
```

### Example 2: Detect when Project Definition is premature

**User:** Create a project to solve our customer onboarding issue.

**Agent:**

```text
HYPOTHESIS: A project has been requested before the onboarding issue has been defined precisely enough to choose an intervention.
CONFIDENCE: ~60% — unclear: which onboarding outcome is failing and for whom.
Q: What observable onboarding result is currently below expectations?
GUESS: Customers take too long to reach their first successful use, rather than failing to complete administrative setup.
```

If the outcome, evidence, and impact remain unclear, propose a confirmed transition back to **Problem Framing** rather than forcing a project definition.

---

## 4. Task Definition

### Example 1: Prepare a quarterly business review

**User:** Break down the work needed for our quarterly business review.

**Agent:**

```text
HYPOTHESIS: The desired outcome is an approved review deck that explains performance, risks, decisions required, and next-quarter priorities.
CONFIDENCE: ~45% — missing: audience, meeting date, required inputs, owner, and approval process.
Q: Who is the decision-making audience for the review?
GUESS: Department leadership, because that determines the level of detail and which decisions the deck must support.
```

**Example task summary after clarification:**

```markdown
## Task Definition Summary

### Task 1: Confirm the review narrative and required decisions

- **Outcome:** Agreed storyline covering performance, risks, and decisions required from leadership.
- **Owner:** Review lead.
- **Priority:** Critical.
- **Dependencies:** Leadership expectations and previous-quarter commitments.
- **Due date or time window:** Before data collection is finalized.
- **Definition of Done:** Sponsor confirms the storyline and decision questions in writing.

### Task 2: Collect and validate performance inputs

- **Outcome:** Complete dataset with source, period, owner, and validation status.
- **Owner:** Functional metric owners coordinated by the review lead.
- **Priority:** Critical.
- **Dependencies:** Confirmed metric list and reporting cutoff date.
- **Due date or time window:** At least five working days before the review.
- **Definition of Done:** Required metrics are present, reconciled, and approved by their owners.

### Task 3: Draft the review deck

- **Outcome:** First complete deck aligned to the agreed narrative.
- **Owner:** Review lead.
- **Priority:** High.
- **Dependencies:** Validated inputs and confirmed storyline.
- **Due date or time window:** Three working days before sponsor review.
- **Definition of Done:** Every section contains a key message, evidence, and requested action where applicable.

### Task 4: Run sponsor review and close feedback

- **Outcome:** Final approved deck ready for the meeting.
- **Owner:** Review lead; sponsor approves.
- **Priority:** Critical.
- **Dependencies:** Complete draft deck.
- **Due date or time window:** Final approval one working day before the meeting.
- **Definition of Done:** Sponsor feedback is resolved and the final version is distributed to presenters.

### Overall

- **Milestones:** Storyline approval; data validation; draft review; final approval.
- **Critical dependencies:** Metric owners and sponsor availability.
- **Current blockers:** Any unconfirmed metric definitions or missing owners.
- **Open ownership decisions:** Presenter ownership for each review section.
```

**Closing proposal:**

```text
CONFIDENCE: ~95%
The task breakdown is ready for execution. I do not see a need for another interview mode. Do you confirm this summary as the final output?
```

### Example 2: Detect when task breakdown is premature

**User:** Give me the tasks for improving communication between teams.

**Agent:**

```text
HYPOTHESIS: Task Definition is premature because “improving communication” does not yet identify the observable problem or the chosen intervention.
CONFIDENCE: ~55% — missing: affected teams, failure pattern, business impact, and desired behavior.
Q: What is currently happening between the teams that should not happen, or failing to happen when it should?
GUESS: Dependencies are discovered late because teams do not share changes early enough.
```

If the problem is not established, summarize the gap and ask permission to move to **Problem Framing**.

---

## Cross-mode examples

### From Problem Framing directly to Task Definition

Use this path when the problem is clear and the intervention is already agreed.

```text
CONFIDENCE: ~95%
The problem and corrective action are already agreed: incomplete requests will be prevented through a mandatory intake checklist. Brainstorming and Project Definition would add little value. I recommend moving directly to Task Definition. Do you agree?
```

### From Brainstorming back to Problem Framing

Use this path when idea generation exposes disagreement about the underlying challenge.

```text
CONFIDENCE: ~65% — the ideas address different problems, which suggests the challenge is not yet shared.
Before generating more alternatives, I recommend returning to Problem Framing to agree on the affected user, observable failure, and impact. Do you agree?
```

### End after one mode

A next mode is not mandatory.

```text
CONFIDENCE: ~95%
The problem has been defined to the level you requested. No solution generation or planning was requested, so I do not recommend another mode. Do you confirm the summary as the final output?
```

## Anti-pattern examples

### Do not batch questions

Avoid:

```text
Who is affected, what is the impact, what data do you have, what is the deadline, and what have you tried?
```

Prefer:

```text
Q: Who experiences the problem directly?
GUESS: The project coordinators, because they appear to absorb the rework created by missing information.
```

### Do not confuse a proposed solution with the problem

Avoid:

```text
The problem is that we do not have a dashboard.
```

Prefer:

```text
HYPOTHESIS: The observable problem is delayed visibility into project risks; a dashboard is one possible intervention, not the problem itself.
```

### Do not force every mode

Avoid automatically running:

```text
Problem Framing → Brainstorming → Project Definition → Task Definition
```

Instead, select only the modes that add value, explain the recommendation, and ask for confirmation before every transition.

### Do not treat confidence as a formula

Avoid increasing confidence by a fixed amount for each answered question. Confidence remains a reasoned estimate of whether the agent understands the user's underlying intent well enough to predict likely reactions to the next three questions.
